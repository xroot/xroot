# Tip to change text on the buttons

You can use Microsoft Paint and create a text box with a text box as follow :
	- Calibri
	- size 18
	